from tkinter import ttk

# Define some colours
colours = {
    'bg': '#222222',
    'light': '#555555',
    'dark': '#111111',
    'accent': '#008CBA'
}

# Define fonts
fonts = {
    'title': ('Arial', 18, 'bold'),
    'header': ('Arial', 14, 'bold'),
    'content': ('Arial', 12)
}

# Function to create a custom Tkinter theme
def create_custom_theme():
    style = ttk.Style()
    style.theme_create('Custom', parent='default', settings={
        'TButton': {
            'configure': {
                'font': fonts['content'],
                'padding': 5,
                'foreground': colours['dark'],
                'background': colours['light']
            }
        },
        'TLabel': {
            'configure': {
                'font': fonts['content'],
                'foreground': colours['dark'],
                'background': colours['bg']
            }
        },
        'TEntry': {
            'configure': {
                'font': fonts['content'],
                'foreground': colours['dark'],
                'background': colours['light']
            }
        }
    })
    return style

# Homepage function to create a modern home page
def homepage(root):
    style = create_custom_theme()

    # Create a frame for the home page
    home_frame = ttk.Frame(root, style='Custom.TFrame')
    home_frame.pack(fill='both', expand=True)

    # Add a title label
    title_label = ttk.Label(home_frame, text="Raptors Roster App", font=fonts['title'])
    title_label.pack(pady=(30, 10))

    # Add schedule and roster buttons
    schedule_button = ttk.Button(home_frame, text="View Schedule")
    schedule_button.pack(pady=10)

    roster_button = ttk.Button(home_frame, text="View Roster")
    roster_button.pack(pady=10)